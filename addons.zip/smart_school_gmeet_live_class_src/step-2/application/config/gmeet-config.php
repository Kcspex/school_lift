<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');
//Build: 210620
$config['version'] = "3.0";
