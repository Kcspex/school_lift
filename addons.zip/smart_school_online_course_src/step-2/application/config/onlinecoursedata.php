<?php

// $config['instructor_type'] = array(
//     'standard' => lang('standard'),
//     'pro' => lang('pro'),
//     'ellite' => lang('ellite')
//     );

$config['courseprovider'] = array(
    'youtube' => lang('youtube'),	
	'vimeo' => lang('vimeo'),  
	'html5' => lang('html5'),
	's3_bucket' => lang('s3_bucket')   
	);

// $config['courseprovidericon'] = array(
//     'youtube' => 'fa-youtube-square',
// 	'html5' => 'fa-html5',
// 	'vimeo' => 'fa-vimeo-square',    
// 	);

// $config['courseiconcode'] = array(
//     'youtube' => '&#xf166',
// 	'html5' => '&#xf13b', 
// 	'vimeo' => '&#xf194',    
// 	);

// $config['level'] = array(
//     'beginner' => lang('beginner'),
// 	'intermediate' =>lang('intermediate'),
// 	'advanced' => lang('advanced'),
// 	);

$config['lesson_type'] = array(
    'video' => lang('video'),
	'pdf' => lang('pdf'),
	'text' => lang('text'),
	'document' => lang('document'),
	);

// $config['course_thumbnail_path'] = "uploads/course_images/";	
// $config['student_images_path'] = "uploads/student_images/";	
// $config['staff_images_path'] = "uploads/staff_images/";	
// $config['testimonial_images_path'] = "uploads/testimonial_image/";	
// $config['myVAR'] = 'TEST HERE';
?>    