<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');
//Build: 210615
$config['version'] = "1.0";
